#!/system/bin/sh

rm -rf /sdcard/Android/ct
rm -rf /data/powercfg.json
rm -rf /data/powercfg.sh
exit 0
